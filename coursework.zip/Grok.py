from datetime import datetime, time as dtime
from graphics import *
import csv

# === DATA ===
data_list = []
defined_airport_codes = {
    "LHR": "London Heathrow",
    "MAD": "Madrid Adolfo Suárez-Bajaras",
    "CDG": "Charles De Gaulle International",
    "IST": "Istanbul Airport International",
    "AMS": "Amsterdam Schiphol",
    "LIS": "Lisbon Portela",
    "FRA": "Frankfurt Main",
    "FCO": "Rome Fiumicino",
    "MUC": "Munich International",
    "BCN": "Barcelona International"
}

defined_airlines = {
    "BA": "British Airways",
    "AF": "Air France",
    "AY": "Finnair",
    "KL": "KLM",
    "SK": "Scandinavian Airlines",
    "TP": "TAP Air Portugal",
    "TK": "Turkish Airlines",
    "W6": "Wizz Air",
    "U2": "easyJet",
    "FR": "Ryanair",
    "A3": "Aegean Airlines",
    "SN": "Brussels Airlines",
    "EK": "Emirates",
    "QR": "Qatar Airways",
    "IB": "Iberia",
    "LH": "Lufthansa"
}

window_start = dtime(0, 0)
window_end = dtime(12, 0)

# === FUNCTIONS ===
def load_csv_(filename):
    with open(filename, 'r') as file:
        csvreader = csv.reader(file)
        next(csvreader)  # skip header
        for row in csvreader:
            if row:  # avoid empty rows
                data_list.append(row)

def count_flights_per_airline_by_hour(data_list, airline_code):
    flights_per_hour = {hour: 0 for hour in range(12)}
    for row in data_list:
        try:
            flight_code = row[1][:2]
            dep_time_str = row[3]
            dep_time = datetime.strptime(dep_time_str, "%H:%M").time()
            if flight_code == airline_code and window_start <= dep_time < window_end:
                flights_per_hour[dep_time.hour] += 1
        except:
            continue
    return flights_per_hour

def draw_crisp_arrowhead(win, tip_x, tip_y, direction="up"):
    if direction == "right":
        points = [Point(tip_x, tip_y), Point(tip_x-7, tip_y-3), Point(tip_x-7, tip_y+3)]
    elif direction == "up":
        points = [Point(tip_x, tip_y), Point(tip_x-3, tip_y-7), Point(tip_x+3, tip_y-7)]
    arrow = Polygon(*points)
    arrow.setFill("black")
    arrow.draw(win)

# === MAIN PROGRAM ===
# 1. Get and validate airline code
while True:
    airline_code = input("Enter a two-character Airline code to plot a histogram: ").strip().upper()
    if airline_code in defined_airlines:
        break
    print("Unavailable Airline code please try again.")

# 2. Determine CSV file (you must have the correct file in folder)
# Assuming filename format: LHR2025.csv, CDG2025.csv, etc.
# You can adjust this mapping if needed
airport_to_file = {
    "LHR": "LHR2025.csv",
    "CDG": "CDG2025.csv",
    "MAD": "MAD2025.csv",
    # Add others if needed
}
# For now, assume LHR2025.csv exists — change path as needed
csv_filename = "LHR2025.csv"  # UPDATE THIS PATH IF NEEDED
load_csv_(csv_filename)

# Use first airport found in data or default
airport_code = "LHR"  # Change if you use different file
if data_list:
    airport_code = data_list[0][0]  # assuming col 0 is airport code

flights_per_hour = count_flights_per_airline_by_hour(data_list, airline_code)

# 3. Create window
win = GraphWin("Histogram", 1000, 600)
win.setCoords(0, 0, 100, 100)
win.setBackground("white")

# 4. Title
airline_name = defined_airlines[airline_code]
airport_name = defined_airport_codes.get(airport_code, airport_code)
title = f"Departures by hour for {airline_name} from {airport_name} 2025"
title_text = Text(Point(50, 94), title)
title_text.setSize(16)
title_text.setStyle("bold")
title_text.draw(win)

# 5. Axes
x_axis = Line(Point(15, 20), Point(85, 20))
x_axis.setWidth(2)
x_axis.draw(win)

y_axis = Line(Point(15, 20), Point(15, 80))
y_axis.setWidth(2)
y_axis.draw(win)

# Arrowheads
draw_crisp_arrowhead(win, 85, 20, "right")
draw_crisp_arrowhead(win, 15, 80, "up")

# Axis labels
Text(Point(50, 12), "Hours").draw(win)
Text(Point(8, 70), "Number of\nFlights", justify="center").draw(win)

# 6. Find max for scaling
max_count = max(flights_per_hour.values(), default=1)
scale_y = 55  # max bar height in graph units

# 7. Draw bars and labels
bar_width = 4.2
spacing = 5.8
start_x = 20

for hour in range(12):
    count = flights_per_hour[hour]
    x_center = start_x + hour * spacing
    
    height = (count / max_count) * scale_y if max_count > 0 else 0
    bar = Rectangle(
        Point(x_center - bar_width/2, 20),
        Point(x_center + bar_width/2, 20 + height)
    )
    bar.setFill("lightcoral")
    bar.setOutline("crimson")
    bar.setWidth(1)
    bar.draw(win)
    
    # Number on bar (only if > 0)
    if count > 0:
        label_y = 20 + height + 3
        if height < 10 and count < 10:
            label_y = 20 + height / 2  # inside small bars
            Text(Point(x_center, label_y), str(count)).setTextColor("white")
        Text(Point(x_center, label_y), str(count)).setSize(10).setStyle("bold").draw(win)
    
    # Hour label below
    hour_label = f"{hour:02d}:00"
    Text(Point(x_center, 16), hour_label).setSize(10).draw(win)

# 8. Wait and close
win.getMouse()
win.close()
